import 'package:aswaqalhelal/app/presentation/cubit/create_update_note_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc_observer.dart';
import 'data/notes_local_api.dart';
import 'data/notes_repository.dart';
import 'models/note.dart';

Future<void> main() async {
  Bloc.observer = AppBlocObserver();
  WidgetsFlutterBinding.ensureInitialized();
  // Wrap your app
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<NotesCubit>(
          create: (context) => NotesCubit(
            NotesRepository(
              NotesLocalAPI(),
            ),
          )..getNotes(),
        ),
      ],
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: const MyHomePage(),
        routes: {
          '/': (context) => const MyHomePage(),
          'create-update-note': (context) => const CreateUpdateNote(),
        },
      ),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notes'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).pushNamed('create-update-note');
        },
        child: const Icon(Icons.add),
      ),
      body: BlocBuilder<NotesCubit, NotesState>(
        builder: (context, state) {
          if (state.status == NotesStatus.loading ||
              state.status == NotesStatus.initial) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.status == NotesStatus.failure) {
            return const Center(child: Text('Something went wrong'));
          }
          return ListView.builder(
            itemCount: state.notes.length,
            itemBuilder: (context, index) {
              final note = state.notes[index];
              return ListTile(
                title: Text(note.title),
                trailing: IconButton(
                    onPressed: () {
                      Navigator.of(context).pushNamed(
                        'create-update-note',
                        arguments: note,
                      );
                    },
                    icon: const Icon(Icons.edit)),
                onTap: () {
                  Navigator.of(context).pushNamed(
                    'create-update-note',
                    arguments: note,
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

class CreateUpdateNote extends StatefulWidget {
  const CreateUpdateNote({super.key, this.note});
  final Note? note;

  @override
  State<CreateUpdateNote> createState() => _CreateUpdateNoteState();
}

class _CreateUpdateNoteState extends State<CreateUpdateNote> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();

  @override
  void initState() {
    if (widget.note != null) {
      _titleController.text = widget.note!.title;
    }
    super.initState();
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<CreateUpdateNoteCubit>(
      create: (context) => CreateUpdateNoteCubit(
        NotesRepository(
          NotesLocalAPI(),
        ),
      )..init(widget.note),
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.note == null ? 'Create Note' : 'Update Note'),
        ),
        body: BlocConsumer<CreateUpdateNoteCubit, CreateUpdateNoteState>(
          listener: (context, state) {
            if (state.status == NotesStatus.success) {
              if (widget.note == null) {
                context.read<NotesCubit>().notesAdded(state.resultNote!);
              } else {
                context.read<NotesCubit>().notesUpdated(state.resultNote!);
              }
            } else if (state.status == NotesStatus.failure) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.errorMessage!),
                ),
              );
            } else if (state.status == NotesStatus.loading) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Loading...'),
                ),
              );
            }
          },
          builder: (context, state) {
            return Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _titleController,
                    decoration: const InputDecoration(
                      hintText: 'Title',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        if (value!.length > 5) {
                          return 'Please enter a title less than 5 characters';
                        }
                        return 'Please enter some text';
                      }
                      return null;
                    },
                  ),
                  ElevatedButton(
                    onPressed: () {
                      context.read<CreateUpdateNoteCubit>().submit(
                            title: _titleController.text,
                            context: context,
                          );
                    },
                    child: Text(widget.note == null ? 'Create' : 'Update'),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
