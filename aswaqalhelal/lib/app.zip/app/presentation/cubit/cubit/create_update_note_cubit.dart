import 'package:aswaqalhelal/app/data/notes_repository.dart';
import 'package:aswaqalhelal/app/models/note.dart';
import 'package:flutter/material.dart';
import '../../../models/note.dart';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'create_update_note_state.dart';

class CreateUpdateNoteCubit extends Cubit<CreateUpdateNoteState> {
  CreateUpdateNoteCubit(
    this._repository,
  ) : super(const CreateUpdateNoteState());

  final NotesRepository _repository;

  void init(Note? note) {
    emit(state.copyWith(
      currentNote: note,
    ));
  }

  void submit({
    required String title,
    required BuildContext context,
  }) async {
    emit(state.copyWith(status: NotesStatus.loading));
    try {
      final note = state.currentNote == null
          ? await _repository.createNote(title)
          : await _repository.updateNote(
              state.currentNote!.id,
              title,
            );
      emit(
        state.copyWith(
          status: NotesStatus.success,
          resultNote: note,
        ),
      );
    } catch (e) {
      emit(
        state.copyWith(
          status: NotesStatus.failure,
          errorMessage: state.currentNote == null
              ? 'Failed to create note'
              : 'Failed to update note',
        ),
      );
    }
  }
}
