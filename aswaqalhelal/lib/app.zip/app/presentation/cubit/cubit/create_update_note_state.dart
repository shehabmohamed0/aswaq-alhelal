part of 'create_update_note_cubit.dart';

class CreateUpdateNoteState extends Equatable {
  final Note? currentNote;
  final NotesStatus status;
  final Note? resultNote;
  final String? errorMessage;
  const CreateUpdateNoteState({
    this.currentNote,
    this.status = NotesStatus.initial,
    this.resultNote,
    this.errorMessage,
  });

  CreateUpdateNoteState copyWith({
    Note? currentNote,
    NotesStatus? status,
    Note? resultNote,
    String? errorMessage,
  }) {
    return CreateUpdateNoteState(
      currentNote: currentNote ?? this.currentNote,
      status: status ?? this.status,
      resultNote: resultNote ?? this.resultNote,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }

  @override
  List<Object?> get props => [
        status,
        currentNote,
        resultNote,
        errorMessage,
      ];
}
