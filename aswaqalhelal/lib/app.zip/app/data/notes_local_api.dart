import 'dart:math';

import '../models/note.dart';

class NotesLocalAPI {
  Future<List<Note>> getNotes() async {
    return const [
      Note(
        id: 1,
        title: 'Note 1',
      ),
      Note(
        id: 2,
        title: 'Note 2',
      ),
      Note(
        id: 3,
        title: 'Note 3',
      ),
    ];
  }

  Future<Note> createNote(String title) async {
    return Note(
      id: Random().nextInt(10000000),
      title: title,
    );
  }

  Future<Note> updateNote(int id, String title) async {
    return Note(
      id: id,
      title: title,
    );
  }
}
