import '../models/note.dart';
import 'notes_local_api.dart';

class NotesRepository {
  final NotesLocalAPI _api;
  const NotesRepository(this._api);

  Future<List<Note>> getNotes() async {
    try {
      await Future.delayed(const Duration(seconds: 2));
      return await _api.getNotes();
    } catch (e) {
      // Here we can handle the error and throw a custom exception
      rethrow;
    }
  }

  Future<Note> createNote(String title) async {
    return _api.createNote(title);
  }

  Future<Note> updateNote(int id, String title) async {
    return _api.updateNote(id, title);
  }
}
